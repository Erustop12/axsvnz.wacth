const config = require('@axiewatch/eslint-config');

module.exports = config;
