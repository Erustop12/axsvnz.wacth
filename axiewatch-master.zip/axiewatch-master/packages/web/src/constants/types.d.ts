declare module '*.md';
