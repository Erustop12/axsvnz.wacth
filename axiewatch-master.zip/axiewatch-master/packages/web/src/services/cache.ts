import memoryCache from 'memory-cache';

const cache = new memoryCache.Cache();

export { cache };
