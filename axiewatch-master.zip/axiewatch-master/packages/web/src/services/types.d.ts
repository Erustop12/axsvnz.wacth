declare module 'fetch-throttle';
