export const fonts = {
  heading: 'Inter',
  body: 'Inter',
};
