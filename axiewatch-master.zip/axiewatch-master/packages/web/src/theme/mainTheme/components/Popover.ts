export const PopoverStyles = {
  parts: ['content'],
  baseStyle: {
    content: {
      _focus: {
        boxShadow: 'none',
      },
    },
  },
};
