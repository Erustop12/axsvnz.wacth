import { mainTheme } from './mainTheme';

export { mainTheme };
