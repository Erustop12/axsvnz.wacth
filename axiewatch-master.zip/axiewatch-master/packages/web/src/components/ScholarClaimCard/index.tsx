export { ScholarClaimCard } from './ScholarClaimCard';
