export { TooltipPredictionSlp } from './TooltipPredictionSlp';
