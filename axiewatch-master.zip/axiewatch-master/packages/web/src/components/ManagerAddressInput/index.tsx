export { ManagerAddressInput } from './ManagerAddressInput';
